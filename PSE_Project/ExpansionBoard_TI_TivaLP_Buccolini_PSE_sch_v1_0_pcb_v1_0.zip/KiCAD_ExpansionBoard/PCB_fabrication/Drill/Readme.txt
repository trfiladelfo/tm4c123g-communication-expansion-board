The format used is Excellon, Imperial, Decimal format.
Drill folder include following files:

TM4C123G_CommExpBoard.drl = drill file
TM4C123G_CommExpBoard-drl.rpt = drill report (plain text)
TM4C123G_CommExpBoard-drl_map.pho = drill map

