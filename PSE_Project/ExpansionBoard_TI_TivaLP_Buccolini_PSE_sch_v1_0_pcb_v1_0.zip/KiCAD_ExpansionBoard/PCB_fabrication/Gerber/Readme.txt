The format used is RS274X format 3.4, Imperial, Leading zero omitted, Abs format. This is very usual settings.

The Gerber folder has the following gerber files:

TM4C123G_CommExpBoard-B_CU.gbl = Bottom copper
TM4C123G_CommExpBoard-B_Mask.gbs = Bottom soldermask
TM4C123G_CommExpBoard-F_Cu.gtl = Top (front) copper
TM4C123G_CommExpBoard-F_Mask.gts = Top (front) soldermask
TM4C123G_CommExpBoard-F_SilkS.gto = Top (front) silkscreen
TM4C123G_CommExpBoard-Edge_Cuts.gbr = Board outline
TM4C123G_CommExpBoard-Dwgs_User.gbr = User drawings (cross-hair and other draft)
