BYOB Getting Started Pack

==How to use this guide==
This guide contains suggested resources that may or may not assist you in the creation of a custom BoosterPack plug-in module that is compatible with Texas Instruments LaunchPad MCU Evaluation kits. This guide is meant to be helpful to novice hardware designers but may also assist more experienced designers. 