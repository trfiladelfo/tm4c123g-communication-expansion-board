This zip includes the source and export files for the LaunchPad Rocket.
This rocket can be included in your designs if your solution adheres 
to the BoosterPack standard that is defined at http://www.ti.com/byob

The source file (.svg) was created in Inkscape.
PNG and PDF exports of the LaunchPad Rocket are also provided.